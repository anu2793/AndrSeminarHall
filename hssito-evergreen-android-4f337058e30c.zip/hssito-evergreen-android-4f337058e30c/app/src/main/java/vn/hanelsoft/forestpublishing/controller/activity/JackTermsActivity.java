package vn.hanelsoft.forestpublishing.controller.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import vn.hanelsoft.forestpublishing.R;
import vn.hanelsoft.forestpublishing.util.AppConstants;

/**
 * Created by dinhdv on 7/24/2017.
 */

public class JackTermsActivity extends BaseActivity {
    private TextView mTvOne, mTvTwo, mTvThree;
    private boolean isShowMenu = true;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_jack_terms;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupTitleScreen(getString(R.string.txt_privacy));
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            isShowMenu = bundle.getBoolean(AppConstants.KEY_SEND.KEY_DATA, false);
        }
        if (isShowMenu) {
            btnBack.setVisibility(View.GONE);
            btnMenu.setVisibility(View.VISIBLE);
        } else {
            btnBack.setVisibility(View.VISIBLE);
            btnMenu.setVisibility(View.INVISIBLE);
        }
        btnShop.setVisibility(View.INVISIBLE);
        mTvOne = (TextView) findViewById(R.id.tv_one);
        mTvTwo = (TextView) findViewById(R.id.tv_two);
        mTvThree = (TextView) findViewById(R.id.tv_three);
        mTvOne.setText("株式会社 HIROPRO（以下「当社」といいます）は、当社が提供する「EverGreen」（以下「本サービス」といいます）の利用にあたって利用者に適用される「EverGreen」利用規約の一部を構成するものとして、以下のとおりプライバシーポリシー（以下「本ポリシー」といいます）を定めます。本サービスにおいて利用者から取得した個人情報は、本ポリシーに従って管理されます。\n" +
                "\n" +
                "１．収集する個人情報\n" +
                "　本ポリシーにおいて、「個人情報」とは、利用者の識別に係る情報、通信サービス上の行動履歴、その他利用者のスマートフォン、PC等の端末において利用者又は利用者の端末に関連して生成又は蓄積された情報であって、本ポリシーに基づき当社が収集するものを意味するものとします。\n" +
                "　本サービスにおいて、当社が収集する個人情報は、以下のとおりです。\n" +
                "　（１）氏名、生年月日、住所、電話番号、メールアドレス\n" +
                "　（２）端末機種名\n" +
                "　（３）OSバージョン情報やOSのID\n" +
                "　（４）Cookie、位置情報\n" +
                "　（５）その他当社が定める入力フォームに利用者が入力する情報\n" +
                "\n" +
                "２．個人情報の利用目的\n" +
                "　利用者からお預かりした個人情報の利用目的は、以下のとおりです。\n" +
                "（１）本サービスに関する登録の受付、本人確認、利用料金の計算等本サービスの提供、維持、保護及び改善のため\n" +
                "（２）本サービスに関するご案内、お問い合わせ等への対応のため\n" +
                "（３）本サービスを通じて利用者が閲覧した動画の内容に関連した商品・サービス等をご案内するため\n" +
                "（４）本サービスに関する当社の規約、ポリシー等に違反する行為に対する対応のため\n" +
                "（５）本サービスの利用に関する動向の調査、統計、分析のため\n" +
                "（６）本サービスの不具合把握等補足情報収集のため\n" +
                "（７）上記の利用目的に付随する利用目的のため\n");
        mTvTwo.setText("３．個人情報の第三者への開示・提供の禁止\n" +
                "　当社は、利用者よりお預かりした個人情報を適切に管理し、次のいずれかに該当する場合を除き、個人情報を第三者に開示いたしません。\n" +
                "（１）利用者（利用者の包括承継人を含みます。）の同意がある場合\n" +
                "（２）当社が利用目的の達成に必要な範囲内において個人情報の取扱いの全部又は一部を委託する場合\n" +
                "（３）人の生命、身体、人格権又は財産の保護のために必要がある場合であって、本人の同意を得ることが困難であるとき\n" +
                "（４）公衆衛生の向上又は児童の健全な育成の推進のために特に必要がある場合であって、本人の同意を得ることが困難であるとき\n" +
                "（５）国の機関若しくは地方公共団体又はその委託を受けた者その他の公的団体が法令の定める事務を遂行することに対して協力する必要がある場合であって、利用者の同意を得ることによって当該事務の遂行に支障を及ぼすおそれがある場合\n" +
                "（６）合併その他の事由による事業の承継に伴って個人情報が提供されるとき\n" +
                "（７）その他法令に基づき開示することが必要であるとき\n" +
                "\n" +
                "４．共同利用\n" +
                "当社は、本サービスを提供するために、本サービスに動画を提供する提携企業との間で、本ポリシー第１項に定めた個人情報を、第2項に定めた目的のため、共同利用することがあります。共同利用する場合であっても、次項に定める手続は当社において行い、個人情報の取扱に関するお問合せ窓口は、本プライバシーポリシー末尾記載のとおりです。\n");
        mTvThree.setText("５．個人情報の照会等\n" +
                "　利用者がご本人の個人情報の照会・修正・利用停止・削除などをご希望される場合には、個人情報保護法その他の法令に従い、当社の定める手続に則って、身分証明書を提出していただく等によりご本人であることを確認の上、対応させていただきます。当該個人情報が存在しないときや、技術上の理由でその存否が分からない場合は、その旨を通知いたします。\n" +
                "なお、上記手続にあたっては、当社所定の費用をお支払いいただく場合があります。また、本サービスの性質上、個人情報を削除した場合には、本サービスをご利用できなくなる場合もあります。\n" +
                "\n" +
                "６．法令、規範の遵守と見直し\n" +
                "　当社は、保有する個人情報に関して適用される日本の法令、その他規範を遵守するとともに、本ポリシーの内容を適宜見直し、その改善に努めます。\n" +
                "\n" +
                "７．プライバシーポリシーの変更\n" +
                "　当社は、必要に応じて、本ポリシーを変更することがあります。利用者が本サービスを利用するにあたっては、変更後の本ポリシーに同意していただく必要があります。当社は、本ポリシー変更後速やかに、変更後のポリシーを表示します。なお、利用者が本ポリシー変更後に本サービスを利用した場合は、変更後の本ポリシーに同意したものとみなします。\n" +
                "\n" +
                "お問い合せ\n" +
                "　当社の個人情報の取扱に関するお問い合せは下記までご連絡ください。\n" +
                "\n" +
                "株式会社 HIROPRO\n" +
                "〒150-0031　東京都渋谷区桜丘町14-10-511\n" +
                "TEL:03-6809-0453　 FAX:03-6809-0454\n" +
                "フリーダイアル:0120-043-019\n" +
                "Mail:support@hiropro.co.jp\n");

    }
}
