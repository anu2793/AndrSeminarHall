package vn.hanelsoft.forestpublishing.controller.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import vn.hanelsoft.forestpublishing.R;
import vn.hanelsoft.forestpublishing.util.AppConstants;

/**
 * Created by dinhdv on 7/24/2017.
 */

public class TermsActivity extends BaseActivity {
    private TextView mTvContent;
    private boolean isShowBack = false;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_terms;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupTitleScreen(getString(R.string.name_menu_business));
        Bundle bundle = getIntent().getExtras();
        if (bundle != null)
            isShowBack = bundle.getBoolean(AppConstants.KEY_INTENT.SHOW_BACK.toString(), false);
        btnBack.setVisibility(isShowBack ? View.VISIBLE : View.INVISIBLE);
        mTvContent = findViewById(R.id.tv_title);
        btnShop.setVisibility(View.VISIBLE);
        mTvContent.setText("◎「特定商取引に関する法律」に基づく表示\n" +
                "\n" +
                "１．販売価格（役務の対価）\n" +
                "　　EverGreenの購入画面にて記載のとおり\n" +
                "２．対価の支払時期・方法\n" +
                "　　【グーグル用】Google Inc. 及びお客様が選択した支払い方法に関するクレジットカード会社及びプリペードカード会社の規約に基づく。\n" +
                "３．役務の提供時期\n" +
                "対価の支払後直ちに。\n" +
                "４．返金の特約\n" +
                "　　本サービスの特性上、法令において特に義務付けられる場合を除き、返金はいたしません。利用料金を支払後の撤回・解除・取消等はできませんので、予め御了承ください。\n" +
                "５．事業者の名称・住所・代表者名・お問合せ先\n" +
                "　　名称：株式会社HIROPRO\n" +
                "　　住所：（事務所所在地）〒150-0031東京都渋谷区桜丘町14－10－511\n" +
                "　　　　 （本店所在地）〒700-0913　岡山県岡山市北区大供2－2－3\n" +
                "　　代表者：成廣通義\n" +
                "　　お問合せ先：03-6809-0453\n" +
                "    なお、動画の内容に関するお問合せについては、動画の製作業者から直接回答する場合があります。\n" +
                "６．販売価格（役務の対価）以外にお客様にご負担頂く金額\n" +
                "　　本アプリのインストール、並びに本サービス利用時等のアプリケーション動作時における通信における通信に必要な通信料。\n" +
                "７．サービス内容に瑕疵がある場合の責任\n" +
                "　　弊社は、本サービスについて、その完全性、正確性、有用性等に関するいかなる保証もいたしません。また、弊社が責任を負う場合でも、責任の範囲は、お客様に生じた現実且つ直接の損害の範囲の限り、弊社の予見の有無にかかわらず、特別の事情から生じた損害、逸失利益、間接損害、その他の損害について弊社は一切の責任を負わないものとします。但し弊社の故意又は重大な過失による場合はこの限りではありません。\n" +
                "８．本サービスを利用可能な動作環境\n" +
                "【グーグル用】対応端末：5.0 – 5.1.1 、 6.0 – 6.0.1 、 7.0 – 7.1.2等\n");
    }
}
