package vn.hanelsoft.forestpublishing.util;

/**
 * Created by Kienmt on 1/30/2018.
 */

public interface ItemTouchHelperAdapter {
   void onItemDismiss(int position);
}
