package vn.hanelsoft.forestpublishing.view.adapter;

/**
 * Created by dinhdv on 11/6/2017.
 */

public interface LoopingPagerAdapter {
    int getRealCount();
}
